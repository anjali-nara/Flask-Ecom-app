from app import app
from app.api.routes import  default_routes ,auth_routes, category_routes, cart_routes ,coupen_routes, product_routes, profile_routes, order_routes, payment_routes, profile_routes, review_routes, admin_routes
from app.api.routes import productvarient_routes, employee_routes, delivery_routes
if __name__ == "__main__":
     app.run()


# geenrate a to z

#pip install flask
#pip install flask_pymongo
#pip install flask_jwt_extended