PAYPAL_CLIENT_ID = 'AeL8Gp8kyAtyN-km-wI-q8xZGIxkUMXJf_emTBC0rpfLUdevO27zLo-PCO6RHzAhL-xj0MvO1kmCtFR4'
PAYPAL_CLIENT_SECRET = 'EMCYipEhsQZQnQCqpGkD4gjsEVn_AuKs4uSy9grZ7j1DxlzKff3pDFr6zgxEWgyVpcaeQbvs583Vz7A8'
PAYPAL_MODE = 'sandbox'  # or 'live' for production
