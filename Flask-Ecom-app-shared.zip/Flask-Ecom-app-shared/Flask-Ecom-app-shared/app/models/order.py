from app import mongo
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from bson import ObjectId
from app.models.product import Product
from app.models.product_variant import ProductVariant

class Order:
    collection = mongo.db.orders


    @classmethod
    def get_all(cls):
        return list(cls.collection.find({}))
    
    @classmethod
    def save(cls, data):
        return cls.collection.insert_one(data)
    
    # get all pending stockout out for delivery orders
    # @classmethod
    # def get_all_pending_orders(cls):
    #     return list(cls.collection.find({"status": {"$in": ["pending", "stockout", "out_for_delivery"]}}))
    
    @classmethod
    def get_all_pending_orders(cls):
        orders = cls.collection.find({"status": {"$in": ["pending", "stockout", "out_for_delivery"]}})
        result = []
        for order in orders:
            order_dict = dict(order)
            order_dict["carts"] = []
            for cart in order.get("carts", []):
                # Get variant details
                variant = ProductVariant.find_one({"_id": ObjectId(cart["variant_id"])})
                if variant:
                    # Get product details
                    product = Product.find_one({"_id": ObjectId(variant["product_id"])})
                    if product:
                        cart_info = {
                            "product_name": product["product_name"],
                            "size": variant.get("size", "N/A"),
                            "quantity": cart["quantity"],
                            "status": cart["status"]
                        }
                        order_dict["carts"].append(cart_info)
            result.append(order_dict)
        return result

    @classmethod
    def get_all_pending_by_user(cls, user_id):
        return list(cls.collection.find({"user_id": user_id, "status": "pending"}))
    
    @classmethod
    def get_pending_products_count_for_user(cls, user_id):
        return cls.collection.count_documents({"user_id": user_id, "status": "pending"})
    

    @classmethod
    def update_status(cls, user_id, order_id, status):
        return cls.collection.update_one({"_id": ObjectId(order_id), "user_id": user_id}, {"$set": {"status": status}})
    

    @classmethod
    def get_orders_for_user(cls, user_id):
        return list(cls.collection.find({"user_id": user_id}))
    

    @classmethod
    def update_status_emp(cls, order_id, status):
        return cls.collection.update_one({"order_id": order_id}, {"$set": {"status": status}})
    

    @classmethod
    def get_order_by_id(cls, order_id):
        return cls.collection.find_one({"order_id": order_id})