from app import mongo
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from bson import ObjectId

class Coupen:
    collection = mongo.db.coupens



    @classmethod
    def get_all(cls):
        return list(cls.collection.find({}))
    

    @classmethod
    def create(cls, data):
        return cls.collection.insert_one(data)
    

    @classmethod
    def get_by_id(cls, coupen_id):
        return cls.collection.find_one({"_id": ObjectId(coupen_id)})
    

    @classmethod
    def update(cls, coupen_id, data):
        return cls.collection.update_one({"_id": ObjectId(coupen_id)}, {"$set": data})
    

    @classmethod
    def delete(cls, coupen_id):
        return cls.collection.delete_one({"_id": ObjectId(coupen_id)})