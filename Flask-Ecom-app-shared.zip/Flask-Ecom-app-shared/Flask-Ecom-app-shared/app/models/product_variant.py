from app import mongo
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from bson import ObjectId

class ProductVariant:
    collection = mongo.db.product_variants


    @classmethod
    def find_one(cls, data):
        return cls.collection.find_one(data)
    

    @classmethod
    def get_variant(cls, product_id, color, size, gender):
        return cls.collection.find_one({
            "product_id": str(product_id),
            "color": color,
            "size": size,
            "gender": gender
        })
    




    @classmethod    
    def find_variant_id(cls, product_id, color, size, gender):
        variant = cls.collection.find_one({"product_id": str(product_id), "color": color, 
                                           "size":size,"gender":gender})
        return variant['_id'] if variant else None

    @classmethod
    def get_variants_by_color_and_size(cls, product_id, color, size):
        return list(cls.collection.find({"product_id": str(product_id), "color": color, "size": size}))


    @classmethod
    def get_variants_by_color(cls, product_id, color):
        return list(cls.collection.find({"product_id": str(product_id), "color": color}))

    @classmethod
    def get_variant_by_details(cls, product_id, color, size, gender):
        print(product_id, color, size, gender)
        return cls.collection.find_one({"product_id": str(product_id), "color": color, "size": size, "gender": gender})
    

    @classmethod
    def count_by_product_id(cls, product_id): 
        # No conversion to ObjectId needed
        count = cls.collection.count_documents({"product_id": str(product_id)})  # Ensure it's a string
        return count

    @classmethod
    def get_by_product_id(cls, product_id):
        return list(cls.collection.find({"product_id": str(product_id)}))

    # @classmethod
    # def sum_available_stock_by_product_id(cls, product_id):
    #     aggregate_result = cls.collection.aggregate([
    #         {"$match": {"product_id": str(product_id)}},  # Ensure matching by string
    #         {"$addFields": {"available_stock": {"$toInt": "$available_stock"}}},  # Convert available_stock to int
    #         {"$group": {"_id": None, "total_stock": {"$sum": "$available_stock"}}}
    #     ])
    #     result = list(aggregate_result)
    #     return result[0]['total_stock'] if result else 0

    @classmethod
    def sum_available_stock_by_product_id(cls, product_id):
        aggregate_result = cls.collection.aggregate([
            {"$match": {"product_id": str(product_id)}},  # Match documents by product_id
            {"$addFields": {
                "available_stock": {
                    "$convert": {
                        "input": "$available_stock",
                        "to": "int",
                        "onError": 0,  # Fallback to 0 if conversion fails
                        "onNull": 0    # Fallback to 0 if value is null
                    }
                }
            }},
            {"$group": {
                "_id": None,
                "total_stock": {"$sum": "$available_stock"}
            }}
        ])
        result = list(aggregate_result)
        return result[0]['total_stock'] if result else 0


    @classmethod
    def decrease_stock(cls, product_variant_id, quantity):
        # Fetch the current document to get the available_stock
        document = cls.collection.find_one({"_id": ObjectId(product_variant_id)})
        
        if document:
            # Convert the available_stock to an integer if it is not None
            current_stock = int(document['available_stock']) if 'available_stock' in document else 0
            
            # Calculate the new stock value
            new_stock = current_stock - quantity
            
            # Update the document with the new stock value
            return cls.collection.update_one(
                {"_id": ObjectId(product_variant_id)},
                {"$set": {"available_stock": new_stock}}
            )
        else:
            # Handle the case where no document was found
            return None
    
    @classmethod
    def get_all(cls):
        return list(cls.collection.find({}))
    
    @classmethod
    def create(cls, data):
        return cls.collection.insert_one(data)
    

    @classmethod
    def get_by_id(cls, id):
        product_id = ObjectId(id)
        return cls.collection.find_one({"_id": product_id})
    
    @classmethod
    def delete_by_product_id(cls, product_id):
        return cls.collection.delete_many({"product_id": str(product_id)})
    

    @classmethod
    def update(cls, id, data):
        id = ObjectId(id)
        return cls.collection.update_one({"_id": id}, {"$set": data})
    
    @classmethod
    def delete(cls, id):
        product_id = ObjectId(id)
        return cls.collection.delete_one({"_id": product_id})


    @classmethod
    def find_by_id(cls, data):
        return cls.collection.find_one(data)
