from app import mongo
from werkzeug.security import generate_password_hash, check_password_hash
from bson import ObjectId

class Product:
    collection = mongo.db.products

    @classmethod
    def find_one(cls, data):
        return cls.collection.find_one(data)    

    @classmethod
    def get_all(cls):
        return list(cls.collection.find({}))
    
    @classmethod
    def create(cls, data): 
        result = cls.collection.insert_one(data)
        return str(result.inserted_id)  # Convert ObjectId to string if necessary

    

    @classmethod
    def get_by_id(cls, id):
        product_id = ObjectId(id)
        return cls.collection.find_one({"_id": product_id})
    

    @classmethod
    def update(cls, id, data):
        id = ObjectId(id)
        return cls.collection.update_one({"_id": id}, {"$set": data})
    
    @classmethod
    def delete(cls, id):
        product_id = ObjectId(id)
        return cls.collection.delete_one({"_id": product_id})


    @classmethod
    def find_by_id(cls, data):
        return cls.collection.find_one(data)