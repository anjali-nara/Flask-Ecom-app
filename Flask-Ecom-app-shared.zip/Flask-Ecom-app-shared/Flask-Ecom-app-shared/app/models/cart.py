from app import mongo
from werkzeug.security import generate_password_hash, check_password_hash
from bson import ObjectId

class Cart:
    collection = mongo.db.cart


    @classmethod
    def update_quantity(cls, cart_id, quantity):
        try:
            cls.collection.update_one({"_id": ObjectId(cart_id)}, {"$set": {"quantity": quantity}})
            return True
        except Exception as e:
            raise e

    @classmethod
    def delete(cls, cart_id):
        try:
            cls.collection.delete_one({"_id": ObjectId(cart_id)})
            return True
        except Exception as e:
            raise e
    @classmethod
    def increment_quantity(cls, cart_id):
        try:
            cls.collection.update_one({"_id": ObjectId(cart_id)}, {"$inc": {"quantity": 1}})
            return True
        except Exception as e:
            raise e
        
    @classmethod
    def decrement_quantity(cls, cart_id):
        try:
            # Get the current cart item
            cart = cls.collection.find_one({"_id": ObjectId(cart_id)})
            
            # Check if quantity will become 0 after decrementing
            if cart["quantity"] <= 1:
                # If yes, delete the cart item
                cls.collection.delete_one({"_id": ObjectId(cart_id)})
                print("Cart item deleted as its quantity reached 0")
            else:
                # Otherwise, decrement the quantity by 1
                cls.collection.update_one({"_id": ObjectId(cart_id)}, {"$inc": {"quantity": -1}})
                print("Cart item quantity decremented")
            
            return True
        except Exception as e:
            print(f"Failed to decrement quantity or delete cart item: {e}")
            raise e

        
    @classmethod
    def add_item(cls, user_id, variant_id, quantity):
        try:
            data = {
                "user_id": user_id,
                "variant_id": variant_id,
                "quantity": quantity,
                "status": "pending"
            }
            cls.collection.insert_one(data)
            return True
        except Exception as e:
            raise e

    @classmethod
    def save(cls, data):
        try:
            cls.collection.insert_one(data)
            return True
        except Exception as e:
            raise e
        
    @classmethod
    def get_all_pending_by_user(cls, user_id):
        try:
            return cls.collection.find({"user_id": user_id, "status": "pending"})
        except Exception as e:
            raise e
        

    @classmethod
    def get_pending_products_count_for_user(cls, user_id):
        try:
            return cls.collection.count_documents({"user_id": user_id, "status": "pending"})
        except Exception as e:
            raise e
        

    @classmethod
    def find_one(cls, query):
        try:
            return cls.collection.find_one(query)
        except Exception as e:
            raise e
        

    @classmethod
    def update_one(cls, query, data):
        try:
            cls.collection.update_one(query, data)
            return True
        except Exception as e:
            raise e
        

    @classmethod
    def empty_user_cart(cls, user_id):
        try:
            cls.collection.delete_many({"user_id": user_id, "status": "pending"})
            return True
        except Exception as e:
            raise e
        

    @classmethod
    def get_item(cls, cart_id):
        try:
            return cls.collection.find_one({"_id": ObjectId(cart_id)})
        except Exception as e:
            raise e
        

    @classmethod
    def delete_item(cls, cart_id):
        try:
            cls.collection.delete_one({"_id": ObjectId(cart_id)})
            return True
        except Exception as e:
            raise e
        

    @classmethod
    def get_by_id(cls, cart_id):
        try:
            return cls.collection.find_one({"_id": ObjectId(cart_id)})
        except Exception as e:
            raise e
        

    @classmethod
    def update_status(cls, cart_id, status):
        try:
            cls.collection.update_one({"_id": ObjectId(cart_id)}, {"$set": {"status": status}})
            return True
        except Exception as e:
            raise e