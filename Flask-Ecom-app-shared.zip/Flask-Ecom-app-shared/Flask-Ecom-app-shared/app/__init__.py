from flask import Flask
from flask_pymongo import PyMongo
from flask_jwt_extended import JWTManager
# from dotenv import load_dotenv
import os

# Load environment variables from .env
# load_dotenv()

app = Flask(__name__, template_folder='templates', static_folder='static')
UPLOAD_FOLDER = os.path.join(app.root_path, 'static', 'uploads')  # Use os.path.join to get the absolute path
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

app.config["MONGO_URI"] = "mongodb://localhost:27017/ecom_app"
app.config['JWT_SECRET_KEY'] = "adb"


# app.secret_key = os.environ.get("SECRET_KEY")
app.secret_key = 'ecom'

mongo = PyMongo(app)
jwt = JWTManager(app)

# Your routes and other configurations...

if __name__ == "__main__":
    app.run()