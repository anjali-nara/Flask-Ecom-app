import paypalrestsdk
from config import PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET, PAYPAL_MODE

paypalrestsdk.configure({
  "mode": PAYPAL_MODE,  # sandbox or live
  "client_id": PAYPAL_CLIENT_ID,
  "client_secret": PAYPAL_CLIENT_SECRET
})

def get_paypal_interface():
    # You can further customize this function to return specific API interfaces
    return paypalrestsdk.Api({
      "mode": PAYPAL_MODE,
      "client_id": PAYPAL_CLIENT_ID,
      "client_secret": PAYPAL_CLIENT_SECRET
    })

# Example usage
print("Before defining interface in utils.py")
interface = get_paypal_interface()
print("After defining interface in utils.py")
