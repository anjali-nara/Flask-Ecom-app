from flask import render_template, request, redirect, url_for, session, flash
from app import app
from .decorators import login_required
import logging
from datetime import datetime, timedelta
from bson.objectid import ObjectId 
from flask import jsonify 
from app.models.user import User 
from app.models.payment import Payment 



logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@app.route('/admin', methods=['GET'])
@login_required
def admin():
    return render_template('admin/admin.html')


# view all users

@app.route('/admin_view_users', methods=['GET'])
@login_required
def admin_view_users():
    if session["user_type"] != "admin":
        flash("Unauthorized access.", "error")
        return redirect(url_for('admin_dashboard'))

    users = User.get_all()  # Replace with the actual method call to get all users
    users = list(users)
    return render_template('admin/view_users.html', users=users)



@app.route('/admin_view_payments', methods=['GET'])
@login_required
def admin_view_payments():
    if session["user_type"] != "admin":
        flash("Unauthorized access.", "error")
        return redirect(url_for('admin_dashboard'))

    payments = Payment.find_all()  # Replace with the actual method call to get all payment records
    payments = list(payments)
    return render_template('admin/view_payments.html', payments=payments)



