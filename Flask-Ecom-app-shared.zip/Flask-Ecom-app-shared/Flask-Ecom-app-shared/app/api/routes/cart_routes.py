from flask import render_template, request, redirect, url_for, session, jsonify
from app import app 
from app.models.user import User
from app.models.admin import Admin
from app.models.category import Category
from app.models.product import Product
from app.models.product_variant import ProductVariant
from app.models.cart import Cart
from bson import ObjectId
from .decorators import login_required  # import login_required decorator                           
from flask import flash
from werkzeug.security import generate_password_hash, check_password_hash 
from werkzeug.utils import secure_filename
from app.models.order import Order
from app.models.cart import Cart
from app.api.utils.paypal_service import interface
from datetime import datetime
import os
import paypalrestsdk



# @app.route('/add_to_cart/<product_id>', methods=['POST'])
# def add_to_cart(product_id):
#     user_id = session.get('user_id')
#     if not user_id:
#         flash('You must be logged in to add items to the cart.', 'warning')
#         return redirect(url_for('login'))
    

    
#     # Retrieve the variant details from the form submission.
#     color = request.form.get('color')
#     size = request.form.get('size')
#     gender = request.form.get('gender') 
    
#     try: 
#         variant = ProductVariant.get_variant_by_details(product_id, color, size, gender)
#         print("line 40", variant)
#         if variant:
#             print("line 42", variant['_id'])
#             variant_id = str(variant['_id'])
#             # Proceed to check if this variant exists in the cart and update or add it accordingly.
#             existing_cart_item = Cart.find_one({"user_id": user_id, "variant_id": variant_id, "status": "pending"})
#             if existing_cart_item: 
#                 Cart.increment_quantity(existing_cart_item["_id"])
#                 flash('Item quantity updated in cart!', 'success')
#             else:
#                 # Otherwise, add a new cart item for this variant.
#                 Cart.add_item(user_id, variant_id)
#                 flash('Order placed!', 'success')
#         else:
#             flash('Selected product variant does not exist.', 'error')
        
#         return redirect(url_for('view_cart'))
#     except Exception as e:
#         flash(str(e), 'error')
#         return redirect(url_for('view_product', product_id=product_id))


@app.route('/add_to_cart/<product_id>', methods=['POST'])
def add_to_cart(product_id):
    user_id = session.get('user_id')
    if not user_id:
        flash('You must be logged in to add items to the cart.', 'warning')
        return redirect(url_for('login'))
    print("line 40", request.form)
    color = request.form.get('color')
    size = request.form.get('size')
    gender = request.form.get('gender')
    quantity = int(request.form.get('quantity', 1))  # Default to 1 if quantity is not provided

    try:
        variant = ProductVariant.get_variant_by_details(product_id, color, size, gender)
        if variant:
            variant_id = str(variant['_id'])
            existing_cart_item = Cart.find_one({"user_id": user_id, "variant_id": variant_id, "status": "pending"})

            if existing_cart_item:
                # Increment the quantity of the existing cart item
                new_quantity = existing_cart_item['quantity'] + quantity
                Cart.update_quantity(existing_cart_item["_id"], new_quantity)
                flash('Item quantity updated in cart!', 'success')
            else:
                # Add a new cart item with the given quantity
                Cart.add_item(user_id, variant_id, quantity)
                flash('Item added to cart!', 'success')
        else:
            flash('Selected product variant does not exist.', 'error')

        return redirect(url_for('view_cart'))
    except Exception as e:
        flash(str(e), 'error')
        print(f"Error in add_to_cart: {e}")
        return redirect(url_for('view_product', product_id=product_id))


@app.route('/view_cart')
@login_required
def view_cart():
    user_id = session.get('user_id')
    if not user_id:
        flash('You must be logged in to view your cart.', 'warning')
        return redirect(url_for('login'))

    carts = Cart.get_all_pending_by_user(user_id)
    cart_items_details, subtotal = [], 0

    for cart in carts:
        variant = ProductVariant.get_by_id(cart['variant_id'])
        product = Product.get_by_id(variant['product_id']) if variant else None
        if product and variant:
            total_price = cart['quantity'] * int(variant['cost'])
            print("line 80", total_price)
            subtotal = subtotal+ int(total_price)
            cart_items_details.append({
                'product_name': product['product_name'], 'image': product.get('image', 'default-placeholder.jpg'),
                'variant_color': variant['color'], 'variant_size': variant['size'],
                'variant_gender': variant['gender'], 'quantity': cart['quantity'],
                'individual_price': variant['cost'], 'total_price': total_price,
                'cart_id': str(cart['_id'])  # Convert ObjectId to string
            })

    tax = subtotal * 0.1  # Example tax calculation
    total = subtotal + tax
    cart_ids = [item['cart_id'] for item in cart_items_details]  # Collecting cart IDs for PayPal processing

    return render_template('orders/view_cart.html', cart_items_details=cart_items_details, subtotal=subtotal, tax=tax, total=total, cart_ids=cart_ids)

    



@app.route('/delete_cart_item/<cart_id>', methods=['POST', 'GET'])
def delete_cart_item(cart_id):
    user_id = session.get('user_id')
    print(cart_id)
    if not user_id:
        flash('You must be logged in to delete items from the cart.', 'warning')
        return redirect(url_for('login'))
    
    try:
        # Assuming Cart.delete_item() is a method you will implement
        Cart.delete_item(cart_id)
        flash('Item successfully removed from cart!', 'success')
    except Exception as e:
        flash(str(e), 'error')
    
    return redirect(url_for('view_cart'))


@app.route('/cart/increment/<cart_id>', methods=['POST'])
@login_required
def increment_cart_item(cart_id):
    # Logic to increment the quantity of the cart item
    # Example:
    Cart.increment_quantity(cart_id)
    return jsonify({'success': True})

@app.route('/cart/decrement/<cart_id>', methods=['POST'])
@login_required
def decrement_cart_item(cart_id):
    # Logic to decrement the quantity of the cart item, ensuring it doesn't go below 1
    # Example:
    Cart.decrement_quantity(cart_id)
    return jsonify({'success': True})
