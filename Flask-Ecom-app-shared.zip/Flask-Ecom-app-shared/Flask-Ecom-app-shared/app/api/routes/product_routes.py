# app/profile_routes.py

from flask import render_template, request, redirect, url_for, session
from app import app 
from app.models.user import User
from app.models.admin import Admin
from app.models.category import Category
from app.models.product import Product
from app.models.product_variant import ProductVariant

from .decorators import login_required
from flask import flash
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os
from datetime import datetime
import json




@app.route('/get_all_products')
def get_all_products():
    products = Product.get_all()
    return render_template('index.html', products=products)


@app.route('/view_products')
@login_required
def view_products(): 
    products = Product.get_all()
    for product in products:
        # Fetching the category details as before
        category = Category.get_by_id(product['category_id'])
        if category:
            product['category'] = category.get('category_name', 'Unknown Category')
        else:
            product['category'] = 'Unknown Category' 
        print(product['_id'])
        variants_count = ProductVariant.count_by_product_id(product['_id'])
        product['variants_count'] = variants_count
        total_in_stock = ProductVariant.sum_available_stock_by_product_id(product['_id'])
        product['total_in_stock'] = total_in_stock 

    return render_template('products/view_products.html', products=products)

@app.route('/view_product/<product_id>')
@login_required
def view_product(product_id): 
    product = Product.get_by_id(product_id) 
    category = Category.get_by_id(product['category_id']) 
    product['category_name'] = category.get('category_name', 'Unknown Category') if category else 'Unknown Category'
    product_variants = ProductVariant.get_by_product_id(product_id)
    product['variants'] = product_variants 
    
    return render_template('products/view_product.html', product=product)


# @app.route('/add_product', methods=['GET', 'POST'])
# @login_required
# def add_product():
#     if request.method == 'POST':
#         product_name = request.form['product_name']
#         cost = request.form['cost']
#         in_stock = request.form['in_stock']
#         description = request.form['description'] 
#         created_at = datetime.now()
#         status = request.form['status']

#         category = request.form['category'] 
#         image_file = request.files.get('image')  
#         if image_file:
#             # Process the image file
#             filename = secure_filename(image_file.filename)
#             # Save the file to a desired location
#             image_file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename) 
#             image_file = image_file_path 
#         else:
#             # No image provided
#             filename = None

#         data = {
#             "product_name": product_name,
#             "cost": cost,
#             "in_stock": in_stock,
#             "description": description,
#             "image": filename,  # Use filename instead of image_file
#             "created_at": created_at,
#             "status": status,
#             "category": category
#         }
        
#         product = Product.create(data) 
#         if product:
#             flash("Product added successfully", "success")
#             return redirect(url_for('view_products'))
#         else:
#             flash("Product not added", "error")
#             return redirect(url_for('add_product'))
#     else:
#         categories = Category.get_all()
#         return render_template('products/add_product.html', categories=categories)

@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    if request.method == 'POST':
        print(request.form)
        product_name = request.form['product_name']
        description = request.form['description']
        category_id = request.form['category']
        status = request.form['status']
        # Assuming cost and in_stock are part of the base product, not variant specific
        cost = request.form.get('cost', 0)
        in_stock = request.form.get('in_stock', True)
        
        image_file = request.files.get('image')
        filename = None
        if image_file:
            filename = secure_filename(image_file.filename)
            image_file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            image_file.save(image_file_path)  # Saving the image file

        created_at = datetime.now()

        # Constructing the product data dictionary
        product_data = {
            "product_name": product_name,
            "description": description,
            "category_id": category_id,
            "status": status,  
            "image": filename,
            "created_at": created_at,
        }

        # Creating the product in the database and obtaining the product ID
        product_id = Product.create(product_data)  # Adjust based on your actual Product model method

        # Handling variants
        variants_json = request.form.get('variants_json')
        if variants_json:
            variants = json.loads(variants_json)
            for variant in variants:
                variant['product_id'] = product_id  # Linking variant to the product
                # Create each variant in the database
                ProductVariant.create(variant)  # Adjust based on your actual Product model method

        flash("Product and its variants added successfully.", "success")
        return redirect(url_for('view_products'))
    else:
        categories = Category.get_all()  # Adjust based on your actual method to fetch categories
        return render_template('products/add_product.html', categories=categories)


    
@app.route('/edit_product/<product_id>', methods=['GET', 'POST'])
@login_required
def edit_product(product_id):
    product = Product.get_by_id(product_id)  # Assuming this fetches product details
    if request.method == 'POST':
        product_name = request.form['product_name']
        description = request.form['description']
        category_id = request.form['category']
        status = request.form['status']
        cost = request.form.get('cost', 0)  # Assuming cost is a direct product attribute
        # Handling the optional image file upload
        image_file = request.files.get('image')
        filename = None
        if image_file:
            filename = secure_filename(image_file.filename)
            image_file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            image_file.save(image_file_path)


        product_data = {
            "product_name": product_name,
            "description": description,
            "category_id": category_id,
            "status": status,
            "image": filename,
        }
        Product.update(product_id, product_data)  # Update the product
        # Handling existing variants update
        variant_ids = request.form.getlist('variant_ids[]')
        for variant_id in variant_ids:
            variant_data = {
                "color": request.form.get(f"variant_color_{variant_id}", ""),
                "size": request.form.get(f"variant_size_{variant_id}", ""),
                "cost": request.form.get(f"variant_cost_{variant_id}", 0),
                "available_stock": request.form.get(f"variant_stock_{variant_id}", 0),
                "gender": request.form.get(f"variant_gender_{variant_id}", ""),
            }
            ProductVariant.update(variant_id, variant_data)  # Update each variant
        
        # Handling new variants addition
        new_variant_colors = request.form.getlist('new_variant_color[]')
        new_variant_sizes = request.form.getlist('new_variant_size[]')
        new_variant_costs = request.form.getlist('new_variant_cost[]')
        new_variant_stocks = request.form.getlist('new_variant_available_stock[]')
        new_variant_genders = request.form.getlist('new_variant_gender[]')

        for i in range(len(new_variant_colors)):
            new_variant_data = {
                "product_id": product_id,
                "color": new_variant_colors[i],
                "size": new_variant_sizes[i],
                "cost": new_variant_costs[i],
                "available_stock": new_variant_stocks[i],
                "gender": new_variant_genders[i],
            }
            ProductVariant.create(new_variant_data)  # Create new variant

        flash("Product and its variants updated successfully.", "success")
        return redirect(url_for('view_products'))
    else:
        categories = Category.get_all()  # Fetch categories
        product_variants = ProductVariant.get_by_product_id(product_id)  # Fetch variants for the product
        return render_template('products/edit_product.html', product=product, categories=categories, product_variants=product_variants)
    
    

@app.route('/delete_product/<product_id>', methods=['GET'])
@login_required
def delete_product(product_id):
    # First, delete all variants associated with the product
    variants_deleted = ProductVariant.delete_by_product_id(product_id)
    if variants_deleted:
        # Only attempt to delete the product if the associated variants were successfully deleted
        product_deleted = Product.delete(product_id)
        if product_deleted:
            flash("Product and its variants deleted successfully", "success")
        else:
            flash("Product could not be deleted", "error")
    else:
        flash("Product variants could not be deleted", "error")

    return redirect(url_for('view_products'))

