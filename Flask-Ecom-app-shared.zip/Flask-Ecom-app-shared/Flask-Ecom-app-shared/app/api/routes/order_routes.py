# app/profile_routes.py

from flask import render_template, request, redirect, url_for, session, jsonify
from app import app 
from app.models.user import User
from app.models.admin import Admin
from app.models.category import Category
from app.models.product import Product
from app.models.cart import Cart
from bson import ObjectId
from .decorators import login_required  # import login_required decorator                           
from flask import flash
from werkzeug.security import generate_password_hash, check_password_hash 
from werkzeug.utils import secure_filename
from app.models.order import Order
from app.models.product_variant import ProductVariant
from app.api.utils.paypal_service import interface
from datetime import datetime
import os
import paypalrestsdk

@app.route('/user_orders')
@login_required
def user_orders():
    user_id = session.get('user_id')
    orders = Order.get_orders_for_user(user_id)
    for order in orders:
        for cart in order['carts']:
            variant_id = cart['variant_id']  # Retrieve variant_id from cart
            product_variant = ProductVariant.get_by_id(variant_id)  # Fetch product variant details
            if 'product_id' in product_variant:
                product_id = product_variant['product_id']
                product = Product.get_by_id(product_id)  # Fetch product details using product_id
                # Enhance cart dictionary with product details and payment amount
                cart['product'] = {
                    "name": product['product_name'],
                    "price": product_variant['cost'],
                    "total_price": cart['quantity'] * float(product_variant['cost']),
                    "quantity": cart['quantity']
                }
            else:
                print("Product ID not found in product variant.")
    return render_template('orders/user_orders.html', orders=orders)

@app.route('/pending_products_count')
def pending_products_count():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"count": 0}), 401  # User not logged in

    # Assuming you have a function to get the count of pending products
    count = Order.get_pending_products_count_for_user(user_id)
    return jsonify({"count": count})



