# app/profile_routes.py

from flask import render_template, request, redirect, url_for, session, jsonify
from app import app 
from app.models.user import User
from app.models.admin import Admin
from app.models.category import Category
from app.models.product import Product
from app.models.cart import Cart
from app.models.product_variant import ProductVariant
from app.models.order import Order
from bson import ObjectId
from .decorators import login_required  # import login_required decorator                           
from flask import flash
from werkzeug.security import generate_password_hash, check_password_hash 
from werkzeug.utils import secure_filename
from app.models.order import Order
from app.api.utils.paypal_service import interface
from datetime import datetime
import os
import paypalrestsdk

from flask import jsonify



@app.route('/track_order', methods=['GET'])
@login_required
def track_order():
    user_id = session.get('user_id')
    orders = Order.get_orders_for_user(user_id)
    return render_template('orders/track_order.html', orders=orders)