from flask import render_template, request, redirect, url_for, session, jsonify
from app import app 
from app.models.user import User
from app.models.admin import Admin
from app.models.category import Category
from app.models.product import Product
from app.models.product_variant import ProductVariant
from bson import ObjectId
from .decorators import login_required  # import login_required decorator                           
from flask import flash
from werkzeug.security import generate_password_hash, check_password_hash 
from werkzeug.utils import secure_filename
from app.models.order import Order
from app.models.cart import Cart
from app.models.payment import Payment 
from datetime import datetime
import os
import paypalrestsdk
# @app.route('/process_payment', methods=['POST'])
# @login_required
# def process_payment():
#     data = request.json
#     user_id = session.get('user_id')
#     cart_ids = data['cartIds']
#     payment_details = data['paymentDetails']
#     order_id = data['orderID']


    
#     try:
#         # Assuming Payment.save and Order.save methods exist and work correctly
#         Payment.save(payment_details)
#         carts = [Cart.get_by_id(cart_id) for cart_id in cart_ids]
#         data ={
#             "order_id": order_id,
#             "user_id": user_id,
#             "carts": carts,
#             "payment_details": payment_details
#         }
#         Order.save(data)
        
#         for cart_id in cart_ids:
#             Cart.delete(cart_id)
        
#         return jsonify({'success': True, 'message': 'Payment processed successfully'})
#     except Exception as e:
#         return jsonify({'success': False, 'error': str(e)})

@app.route('/process_payment', methods=['POST'])
@login_required
def process_payment():
    data = request.json
    user_id = session.get('user_id')
    cart_ids = data['cartIds']
    payment_details = data['paymentDetails']
    order_id = data['orderID']

    try:
        Payment.save(payment_details)
        total_payment_amount = 0
        # Calculate the total payment amount from payment_details
        if "purchase_units" in payment_details:
            total_payment_amount = sum(float(unit["amount"]["value"]) for unit in payment_details["purchase_units"])

        # Fetch carts and enhance them with product details for order recording
        carts = []
        for cart_id in cart_ids:
            cart = Cart.get_by_id(cart_id)
            if cart:
                product_variant = ProductVariant.get_by_id(cart['variant_id'])
                product = Product.get_by_id(product_variant['product_id']) if product_variant else None
                if product and product_variant:
                    cart['product_details'] = {
                        "product_name": product['product_name'],
                        "variant_color": product_variant['color'],
                        "variant_size": product_variant['size'],
                        "variant_gender": product_variant['gender'],
                        "quantity": cart['quantity'],
                        "individual_price": product_variant['cost'],
                        "total_price": cart['quantity'] * float(product_variant['cost'])
                    }
                    # Append payment amount to each cart
                    cart['payment_amount'] = total_payment_amount
                carts.append(cart)
        
        order_data = {
            "order_id": order_id,
            "user_id": user_id,
            "carts": carts,
            "payment_details": payment_details,
            "created_at": datetime.now().strftime("%Y-%m-%d"),
            "status": "pending"  # Depending on your system's status management
        }
        Order.save(order_data)

        # Delete cart items after successful order processing
        for cart_id in cart_ids:
            Cart.delete(cart_id)

        return jsonify({'success': True, 'message': 'Payment processed successfully'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/payment_success', methods=['GET'])
def payment_success():
    print(request.args)
    print("Payment successful")
    return redirect(url_for('user_orders'))