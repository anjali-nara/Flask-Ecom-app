# app/profile_routes.py

from flask import render_template, request, redirect, url_for, session
from app import app 
from app.models.user import User
from app.models.admin import Admin
from app.models.category import Category
from .decorators import login_required
from flask import flash
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime


@app.route('/view_categories')
@login_required
def view_categories(): 

    categories = Category.get_all() 
    return render_template('admin/view_categories.html', categories=categories) 



@app.route('/add_category', methods=['GET', 'POST'])
def add_category():
    try:
        if request.method == 'POST':
            # Retrieve data from the form
            category_name = request.form.get("category_name").strip()
            description = request.form.get("description").strip()
            status = request.form.get("status").strip()  

            # Create a dictionary with the category data
            category_data = {
                "category_name": category_name,
                "description": description,
                "status": status, 
                "created_at": datetime.utcnow()  # You may need to adjust the timestamp based on your requirements
            }

            # Call the Category model method to create the category
            Category.create(category_data)
            flash("Category added successfully.")
            # Redirect to a success page or a different route
            return redirect(url_for('view_categories'))  # Replace 'admin_dashboard' with the route you want to redirect to after adding the category

        elif request.method == 'GET':
            # Render the form for adding a category
            return render_template('admin/add_category.html')

    except Exception as e:
        # Log the error or handle it appropriately
        print(f"Error adding category: {str(e)}")
        flash("An error occurred while adding the category.")
        return "An error occurred while adding the category.", 500


@app.route('/edit_category/<category_id>', methods=['GET', 'POST'])
def edit_category(category_id):
    try:
        if request.method == 'POST': 
            category_name = request.form.get("category_name").strip()
            description = request.form.get("description").strip()
            status = request.form.get("status").strip()  

            # Create a dictionary with the category data
            category_data = {
                "category_name": category_name,
                "description": description,
                "status": status, 
                "updated_at": datetime.utcnow()  # You may need to adjust the timestamp based on your requirements
            }

            # Call the Category model method to update the category
            Category.update(category_id, category_data)
            flash("Category updated successfully.")
            # Redirect to a success page or a different route
            return redirect(url_for('view_categories'))  # Replace 'admin_dashboard' with the route you want to redirect to after updating the category

        elif request.method == 'GET':
            # Retrieve the category from the database
            category = Category.get_by_id(category_id) 
            return render_template('admin/edit_category.html', category=category)

    except Exception as e:
        # Log the error or handle it appropriately
        print(f"Error editing category: {str(e)}")
        flash("An error occurred while editing the category.")
        return "An error occurred while editing the category.", 500
    

@app.route('/delete_category/<category_id>', methods=['GET', 'POST'])
def delete_category(category_id):
    try:
        Category.delete(category_id)
        flash("Category deleted successfully.")
            # Redirect to a success page or a different route
        return redirect(url_for('view_categories'))  
    except Exception as e:
        # Log the error or handle it appropriately
        print(f"Error deleting category: {str(e)}")
        flash("An error occurred while deleting the category.")
        return "An error occurred while deleting the category.", 500