# app/profile_routes.py

from flask import render_template, request, redirect, url_for, session
from app import app 
from app.models.user import User
from app.models.admin import Admin
from app.models.coupen import Coupen
from .decorators import login_required
from flask import flash
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime


@app.route('/view_coupens')
@login_required
def view_coupens(): 

    coupens = Coupen.get_all() 
    return render_template('products/view_coupens.html', coupens=coupens) 



@app.route('/add_coupen', methods=['GET', 'POST'])
def add_coupen():
    try:
        if request.method == 'POST':
            # Retrieve data from the form
            coupen_name = request.form.get("coupen_name").strip()
            description = request.form.get("description").strip()
            discount = request.form.get("discount").strip()
            status = request.form.get("status").strip()  

            # Create a dictionary with the coupen data
            coupen_data = {
                "coupen_name": coupen_name,
                "description": description,
                "status": status, 
                "discount": discount,
                "created_at": datetime.utcnow()  # You may need to adjust the timestamp based on your requirements
            }

            # Call the Coupen model method to create the coupen
            Coupen.create(coupen_data)
            flash("Coupen added successfully.")
            # Redirect to a success page or a different route
            return redirect(url_for('view_coupens'))  # Replace 'admin_dashboard' with the route you want to redirect to after adding the coupen

        elif request.method == 'GET':
            # Render the form for adding a coupen
            return render_template('products/add_coupen.html')

    except Exception as e:
        # Log the error or handle it appropriately
        print(f"Error adding coupen: {str(e)}")
        flash("An error occurred while adding the coupen.")
        return "An error occurred while adding the coupen.", 500


@app.route('/edit_coupen/<coupen_id>', methods=['GET', 'POST'])
def edit_coupen(coupen_id):
    try:
        if request.method == 'POST': 
            coupen_name = request.form.get("coupen_name").strip()
            description = request.form.get("description").strip()
            discount = request.form.get("discount").strip()
            status = request.form.get("status").strip()  

            # Create a dictionary with the coupen data
            coupen_data = {
                "coupen_name": coupen_name,
                "description": description,
                "status": status, 
                "discount": discount,
                "updated_at": datetime.utcnow()  # You may need to adjust the timestamp based on your requirements
            }

            # Call the Coupen model method to update the coupen
            Coupen.update(coupen_id, coupen_data)
            flash("Coupen updated successfully.")
            # Redirect to a success page or a different route
            return redirect(url_for('view_coupens'))  # Replace 'admin_dashboard' with the route you want to redirect to after updating the coupen

        elif request.method == 'GET':
            # Retrieve the coupen from the database
            coupen = Coupen.get_by_id(coupen_id) 
            return render_template('products/edit_coupen.html', coupen=coupen)

    except Exception as e:
        # Log the error or handle it appropriately
        print(f"Error editing coupen: {str(e)}")
        flash("An error occurred while editing the coupen.")
        return "An error occurred while editing the coupen.", 500
    

@app.route('/delete_coupen/<coupen_id>', methods=['GET', 'POST'])
def delete_coupen(coupen_id):
    try:
        Coupen.delete(coupen_id)
        flash("Coupen deleted successfully.")
            # Redirect to a success page or a different route
        return redirect(url_for('view_coupens'))  
    except Exception as e:
        # Log the error or handle it appropriately
        print(f"Error deleting coupen: {str(e)}")
        flash("An error occurred while deleting the coupen.")
        return "An error occurred while deleting the coupen.", 500