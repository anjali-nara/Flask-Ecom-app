from flask import render_template, request, redirect, url_for, session
from app import app
from app.models.user import User
from app.models.admin import Admin
from app.models.employee import Employee
from werkzeug.security import generate_password_hash, check_password_hash 
import logging
from bson import ObjectId
from flask import flash

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


#     return render_template('users/login.html')
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST': 
        email = request.form.get("email").strip()
        password = request.form.get("password").strip()
        # check if user exists in two databases user and admin
        if User.exists_by_email(email):
            user = User.get_by_email(email)
            if check_password_hash(user['password'], password):
                session["user_id"] = str(user['_id'])
                session["user_type"] = "user"
                return redirect(url_for('user_dashboard'))
            else:
                return "Invalid credentials", 400
            
        elif Admin.exists_by_email(email):
            admin = Admin.get_by_email(email)
            if check_password_hash(admin['password'], password):
                session["user_id"] = admin['_id']
                session["user_id"] = str(admin['_id'])
                session["user_type"] = "admin"
                return redirect(url_for('admin_dashboard'))
            else:
                return "Invalid credentials", 400
        elif Employee.exists_by_email(email):
            employee = Employee.get_by_email(email)
            if check_password_hash(employee['password'], password):
                session["user_id"] = employee['_id']
                session["user_id"] = str(employee['_id'])
                session["user_type"] = "employee"
                return redirect(url_for('employee_dashboard'))
            else:
                return "Invalid credentials", 400
    return render_template('user/login.html')





@app.route('/register_user', methods=['GET', 'POST'])
def register_user(): 
    try:
        if request.method == 'POST':
            email = request.form.get("email").strip()
            if User.exists_by_email(email):
                return "Email already registered", 400

            password = request.form.get("password").strip()
            confirm_password = request.form.get("confirm_password").strip()

            if password != confirm_password:
                return "Passwords do not match", 400

            data = {
                "first_name": request.form.get("first_name").strip(),
                "last_name": request.form.get("last_name").strip(),
                "dob": request.form.get("dob"),
                "gender": request.form.get("gender"), 
                "email": email,
                "phone_number": request.form.get("phone_number").strip(),
                "address": request.form.get("address").strip(),
                "city": request.form.get("city").strip(),
                "zipcode": request.form.get("zipcode").strip(),
                "password": generate_password_hash(password)
            } 
            User.create(data)
            return redirect(url_for('login'))

        return render_template('user/register_user.html')
    except Exception as e:
        logger.error(f"Error during user registration: {str(e)}")
        return "Internal Server Error", 500

@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    try:
        if request.method == 'POST':
            user_type = request.form.get("user_type")
            email = request.form.get("email")

            if user_type == "user" and User.exists_by_email(email):
                session["reset_email"] = email
                session["user_type"] = user_type
                return redirect(url_for('enter_otp'))
            else:
                return "Email not found", 404

        return render_template('users/forgot_password.html')
    except Exception as e:
        logger.error(f"Error during forgot password process: {str(e)}")
        return "Internal Server Error", 500

@app.route('/enter_otp', methods=['GET', 'POST'])
def enter_otp():
    try:
        if request.method == 'POST':
            otp = request.form.get("otp")
            if otp == "11111":
                return redirect(url_for('reset_password'))
            else:
                return "Invalid OTP", 400

        return render_template('users/enter_otp.html')
    except Exception as e:
        logger.error(f"Error during OTP verification: {str(e)}")
        return "Internal Server Error", 500

@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    try:
        if "reset_email" not in session:
            return redirect(url_for('login'))

        if request.method == 'POST':
            new_password = request.form.get("new_password")
            hashed_password = generate_password_hash(new_password)

            if session["user_type"] == "user":
                User.collection.update_one(
                    {"email": session["reset_email"]},
                    {"$set": {"password": hashed_password}}
                )

            session.pop("reset_email", None)
            session.pop("user_type", None)
            return redirect(url_for('login'))

        return render_template('users/reset_password.html')
    except Exception as e:
        logger.error(f"Error during password reset: {str(e)}")
        return "Internal Server Error", 500

@app.route('/logout')
def logout():
    try:
        session.pop('user_id', None)
        session.pop('user_type', None)
        return redirect(url_for('login'))
    except Exception as e:
        logger.error(f"Error during logout: {str(e)}")
        return "Internal Server Error", 500




# register admin secret url
@app.route('/seller_register', methods=['GET', 'POST'])
def seller_register():
    try:
        if request.method == 'POST':
            if Admin.is_admin_registered():
                flash("An admin is already registered. cannot register again", "error")
                return redirect(url_for('seller_register'))

            email = request.form.get("email").strip()
            if Admin.exists_by_email(email):
                flash("Email already registered", "error")
                return "Email already registered", 400

            password = request.form.get("password").strip()
            confirm_password = request.form.get("confirm_password").strip()

            if password != confirm_password:
                flash("Passwords do not match", "error")
                return "Passwords do not match", 400

            data = {
                "user_name": request.form.get("user_name").strip(), 
                "email": email,
                "phone": request.form.get("phone").strip(), 
                "password": generate_password_hash(password)
            }
            Admin.create(data)
            flash("Admin registered successfully!", "success")
            return redirect(url_for('login'))

        return render_template('admin/register_admin.html')
    except Exception as e:
        logger.error(f"Error during admin registration: {str(e)}")
        flash("An error occurred. Please try again.", "error")
        return "Internal Server Error", 500
