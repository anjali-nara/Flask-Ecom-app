#  hi index route
from flask import render_template
from app import app
from app.models.product import Product
from app.models.category import Category

from flask import redirect, url_for, session



@app.route('/')
def index():  
    products = Product.get_all()
    categories = Category.get_all() 
    return render_template('index.html', session=session, products=products, categories=categories)