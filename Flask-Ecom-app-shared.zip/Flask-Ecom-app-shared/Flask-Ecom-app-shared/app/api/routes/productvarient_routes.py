# app/profile_routes.py

from flask import render_template, request, redirect, url_for, session
from app import app 
from app.models.user import User
from app.models.admin import Admin
from app.models.category import Category
from app.models.product import Product
from app.models.product_variant import ProductVariant
from .decorators import login_required
from flask import flash
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os
from datetime import datetime
import json
import requests
from flask import jsonify


# @app.route('/get-variant-info')
# def get_variant_info():
#     try:
#         color = request.args.get('color')
#         product_id = request.args.get('productId')
#         size = request.args.get('size', None)  


#         # Adjust the query based on whether size is provided
#         if size:
#             # Assuming you have a method to get variants by color AND size
#             variants = ProductVariant.get_variants_by_color_and_size(product_id, color, size, gender)
#         else:
#             # Existing method for getting variants by color only
#             variants = ProductVariant.get_variants_by_color(product_id, color)
        
#         if variants:
#             # If size was specifically queried, we only need to find genders
#             if size:
#                 genders = sorted(set([variant['gender'] for variant in variants]))
#                 return jsonify(success=True, genders=genders)
#             # If no specific size was queried, return both sizes and genders
#             else:
#                 sizes = sorted(set([variant['size'] for variant in variants]))
#                 genders = sorted(set([variant['gender'] for variant in variants]))
#                 return jsonify(success=True, sizes=sizes, genders=genders)
#         else:
#             return jsonify(success=False)
#     except Exception as e:
#         return jsonify(success=False, error=str(e)), 500
@app.route('/get-variant-info')
def get_variant_info():
    try:
        color = request.args.get('color')
        size = request.args.get('size')
        gender = request.args.get('gender')
        product_id = request.args.get('productId')

        # Adjust the query to fetch the specific variant
        variant = ProductVariant.get_variant(product_id, color, size, gender)

        if variant:
            return jsonify(success=True, cost=variant['cost'])
        else:
            return jsonify(success=False)
    except Exception as e:
        return jsonify(success=False, error=str(e)), 500
