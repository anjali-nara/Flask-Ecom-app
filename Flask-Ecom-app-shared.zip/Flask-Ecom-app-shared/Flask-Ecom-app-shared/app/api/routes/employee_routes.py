from flask import render_template, request, redirect, url_for, session
from app import app
from app.models.user import User
from app.models.admin import Admin
from app.models.order import Order
from app.models.employee import Employee
from app.models.product_variant import ProductVariant
from app.models.delivery import Delivery
from app.models.product import Product
from app.models.cart import Cart
from app.models.category import Category
import datetime

from werkzeug.security import generate_password_hash, check_password_hash 
import logging
from bson import ObjectId

from flask import flash
from app.models.employee import Employee  # Assuming you have an Employee model
from .decorators import login_required
from flask import jsonify


logger = logging.getLogger(__name__)

@app.route('/employee_register', methods=['GET', 'POST'])
def employee_register():
    try:
        if request.method == 'POST':
            email = request.form.get("email").strip()
            if Employee.exists_by_email(email):
                flash("Email already registered", "error")
                return "Email already registered", 400

            password = request.form.get("password").strip()
            confirm_password = request.form.get("confirm_password").strip()

            if password != confirm_password:
                flash("Passwords do not match", "error")
                return "Passwords do not match", 400

            # Additional employee-specific form data
            data = {
                "first_name": request.form.get("name").strip(),
                "last_name": request.form.get("last_name").strip(),
                "email": email,
                "phone": request.form.get("phone").strip(),
                "city": request.form.get("city").strip(),
                "zip_code": request.form.get("zip_code").strip(),
                "ssn": request.form.get("ssn").strip(),
                "dob": request.form.get("dob"),
                "password": generate_password_hash(password)
            }

            # Create employee record
            Employee.create(data)
            flash("Employee registered successfully!", "success")
            return redirect(url_for('login'))

        return render_template('employee/register_employee.html')
    except Exception as e:
        logger.error(f"Error during employee registration: {str(e)}")
        flash("An error occurred. Please try again.", "error")
        return "Internal Server Error", 500



@app.route('/employee_dashboard')
@login_required
def employee_dashboard():
    try:
        pending_orders = Order.get_all_pending_orders()
        for order in pending_orders:
            payment_details = order.get("payment_details", {})
            purchase_units = payment_details.get("purchase_units", [])
            total_cost = sum(float(unit["amount"]["value"]) for unit in purchase_units)
            
            payer = payment_details.get("payer", {})
            user = User.get_by_id(order['user_id'])  
            order['username'] = user['first_name'] if user else 'Unknown User'
            # order date
            order['order_date'] = payment_details['create_time'][0:10]

            order['total_cost'] = total_cost
            # print(pending_orders)
        return render_template('employee/employee_dashboard.html', pending_orders=pending_orders)
    except Exception as e:
        logger.error(f"Error during employee dashboard: {str(e)}")
        return "Internal Server Error", 500

@app.route('/update_order_status/<order_id>', methods=['POST'])
@login_required
def update_order_status(order_id):
    print("order_id", order_id)
    try:
        print(request.json)
        status = request.json.get("status")  
        Order.update_status_emp(order_id, status)

        if status == 'delivered':
            order_details = Order.get_order_by_id(order_id)
            print(order_details)
            for cart_item in order_details['carts']:
                product_variant_id = cart_item['variant_id']
                quantity = cart_item['quantity']
                
                ProductVariant.decrease_stock(product_variant_id, quantity)

            data = {
                "order_id": order_id,
                "status": "delivered",
                "employee_id": session.get("user_id"),
                "created_at":  datetime.datetime.now()
            }
            # get order details based on id and from that get producvtvairent id and then decrease the count of stock
            delivery = Delivery.save(data)
        return redirect(url_for('employee_dashboard'))
    except Exception as e:
        logger.error(f"Error during updating order status: {str(e)}")
        return "Internal Server Error", 500